# Project Slayers 2 Fishing Macro para Windows

Macro de pesca para Project Slayers 2. Automatiza el lanzamiento de la caña,
el minijuego de la barra, la recolección del pez y, opcionalmente, el
movimiento, el cebo, el descarte de peces, las misiones y las notificaciones a
Discord.

## Cómo funciona

El macro trabaja sobre la imagen de la ventana del juego y envía entradas de
teclado y ratón. No lee la memoria de Roblox. Detecta la barra y la zona de
pesca por color, sigue la posición de la pelota y mantiene el clic cuando es
necesario. También puede leer visualmente el nombre del pez mediante OCR de
Windows para decidir cuándo mantener y soltar `T`.

El archivo `config.json` se crea o ajusta desde la interfaz. Las posiciones,
colores, tiempos y movimientos dependen de la resolución, escala y lugar de
pesca de cada equipo; no copies valores de otro usuario sin calibrarlos.

Funciones principales:

- Calibración de la zona de la barra y selección de los puntos de lanzamiento y recolección.
- Recolección visual del pez mediante OCR y configuración del área que se ignora.
- Movimiento compensatorio con `W`, `A`, `S` y `D` después de capturar.
- Cebo, descarte de peces y cambio automático de la caña.
- Misiones de pesca configurables para los niveles disponibles en el proyecto.
- Webhook de Discord para avisos y capturas del estado del juego.

## Requisitos

- Windows 10/11 de 64 bits.
- Python 3.10 o superior; Python 3.12.x suele ser la opción más estable.
- Roblox abierto y una ventana del juego visible.
- Permisos de accesibilidad/entrada si Windows los solicita.

## Instalación y uso

1. Extrae el ZIP en una carpeta local, por ejemplo `C:\Games\slayers-2-fishing-windows`.
2. Ejecuta `Setup.bat` una vez. Crea `.venv` e instala las dependencias.
3. Abre Roblox y entra al lugar de pesca.
4. Ejecuta `Launch.bat`.
5. Pesca manualmente durante la primera configuración y calibra la barra, los colores, el punto de lanzamiento y el área de recolección.
6. Ajusta los movimientos y los tiempos para tu resolución y spot antes de dejarlo funcionando.

## Extraerlo en Linux

Linux puede descomprimir el archivo, pero este paquete está preparado para
ejecutarse en Windows:

```bash
mkdir -p slayers-2-fishing-windows
unzip slayers-2-fishing-windows.zip -d slayers-2-fishing-windows
```

El contenido quedará en
`slayers-2-fishing-windows/slayers-2-fishing-windows/`. Copia esa carpeta a
Windows y ejecuta allí `Setup.bat` y `Launch.bat`; `unzip` no instala Python ni
convierte los scripts `.bat` en comandos nativos de Linux.

Si no tienes `unzip`, instala `unzip` con el gestor de paquetes de tu
distribución, por ejemplo `sudo pacman -S unzip`, `sudo apt install unzip` o
`sudo dnf install unzip`.

## Webhook de Discord

Crea un canal de texto, abre **Integraciones > Webhooks**, crea un webhook y
pega su URL HTTPS en la configuración. Mantén esa URL privada.

## Aviso

El video enlazado por el autor afirma que el desarrollador principal no
rastrea ni sanciona estos macros. Esa afirmación no es una garantía permanente:
revisa las reglas actuales del juego y úsalo bajo tu propia responsabilidad.

Video de referencia: <https://www.youtube.com/watch?v=medoNFtBf0s>
