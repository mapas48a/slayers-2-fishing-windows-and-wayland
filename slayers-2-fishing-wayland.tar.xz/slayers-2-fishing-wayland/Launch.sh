#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
unset VIRTUAL_ENV

if ! command -v uv >/dev/null 2>&1; then
    printf '%s\n' "uv is required. On Arch Linux, install it with: sudo pacman -S uv" >&2
    exit 1
fi

if ! command -v hyprctl >/dev/null 2>&1 || [[ -z "${HYPRLAND_INSTANCE_SIGNATURE:-}" ]]; then
    printf '%s\n' "Launch this macro from an active Hyprland session." >&2
    exit 1
fi

exec uv run --project "$ROOT" python "$ROOT/src/main.py" "$@"
