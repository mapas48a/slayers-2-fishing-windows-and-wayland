from __future__ import annotations

import json
import os
import shutil
import subprocess
import threading
import time
from collections.abc import Sequence


IS_WAYLAND = bool(os.environ.get("WAYLAND_DISPLAY")) or os.environ.get("XDG_SESSION_TYPE") == "wayland"
IS_HYPRLAND = IS_WAYLAND and bool(os.environ.get("HYPRLAND_INSTANCE_SIGNATURE")) and shutil.which("hyprctl") is not None

_KEYCODES = {
    "space": 57,
    "plus": 13,
    "minus": 12,
    "equal": 13,
    "comma": 51,
    "period": 52,
    "slash": 53,
    "backslash": 43,
    "leftbracket": 26,
    "rightbracket": 27,
    "semicolon": 39,
    "quote": 40,
    "grave": 41,
    "pageup": 104,
    "pagedown": 109,
    "up": 103,
    "down": 108,
    "left": 105,
    "right": 106,
    "insert": 110,
    "delete": 111,
    "home": 102,
    "end": 107,
}
_KEYCODES.update({
    **dict(zip("qwertyuiop", range(16, 26))),
    **dict(zip("asdfghjkl", range(30, 39))),
    **dict(zip("zxcvbnm", range(44, 51))),
    **dict(zip("1234567890", range(2, 12))),
})
_KEYCODES.update({"f%d" % n: 58 + n for n in range(1, 11)})
_KEYCODES.update({"f11": 87, "f12": 88})
_KEYCODES.update({"f%d" % n: 170 + n for n in range(13, 25)})

_KEY_LOCK = threading.Lock()
_PRESSED_KEYS: dict[str, list[int]] = {}
_MONITOR_LOCK = threading.Lock()
_MONITOR_CACHE: tuple[float, list[dict]] = (0.0, [])


class LinuxInputError(RuntimeError):
    pass


def hyprctl_json(endpoint: str) -> list | dict | None:
    if not IS_HYPRLAND:
        return None
    try:
        result = subprocess.run(
            ["hyprctl", "-j", endpoint],
            check=True,
            capture_output=True,
            text=True,
            timeout=2.0,
        )
        return json.loads(result.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError):
        return None


def hyprctl_dispatch(expression: str) -> None:
    if not IS_HYPRLAND:
        raise LinuxInputError("Hyprland cursor control is unavailable outside a Hyprland session")
    try:
        subprocess.run(
            ["hyprctl", "dispatch", expression],
            check=True,
            capture_output=True,
            text=True,
            timeout=2.0,
        )
    except FileNotFoundError as exc:
        raise LinuxInputError("hyprctl was not found; cursor positioning on Omarchy needs Hyprland") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        raise LinuxInputError(detail or "Hyprland rejected the cursor command") from exc
    except subprocess.TimeoutExpired as exc:
        raise LinuxInputError("Hyprland did not respond to the cursor command") from exc


def hyprland_clients() -> list[dict]:
    result = hyprctl_json("clients")
    return result if isinstance(result, list) else []


def hyprland_monitors() -> list[dict]:
    global _MONITOR_CACHE
    now = time.monotonic()
    with _MONITOR_LOCK:
        stamp, cached = _MONITOR_CACHE
        if cached and now - stamp < 2.0:
            return cached
    result = hyprctl_json("monitors")
    monitors = result if isinstance(result, list) else []
    if monitors:
        with _MONITOR_LOCK:
            _MONITOR_CACHE = (now, monitors)
    return monitors


def find_game_client() -> dict | None:
    choices: list[tuple[int, int, dict]] = []
    for index, client in enumerate(hyprland_clients()):
        if not isinstance(client, dict) or not client.get("mapped", True) or client.get("hidden", False):
            continue
        size = client.get("size") or ()
        if len(size) < 2 or int(size[0]) < 32 or int(size[1]) < 32:
            continue
        details = " ".join(str(client.get(key) or "") for key in (
            "class", "title", "initialClass", "initialTitle", "xdgTag", "xdgDescription",
        )).lower()
        if "sober" in details or "vinegar" in details:
            rank = 0
        elif "roblox" in details:
            rank = 1
        else:
            continue
        choices.append((rank, index, client))
    if not choices:
        return None
    choices.sort(key=lambda item: (item[0], not bool(item[2].get("visible", True)), item[1]))
    return choices[0][2]


def virtual_screen_bounds() -> tuple[int, int, int, int] | None:
    monitors = hyprland_monitors()
    visible = [m for m in monitors if isinstance(m, dict) and not m.get("disabled", False)]
    if not visible:
        return None
    try:
        x0 = min(int(m.get("x", 0)) for m in visible)
        y0 = min(int(m.get("y", 0)) for m in visible)
        x1 = max(int(m.get("x", 0)) + int(m["width"]) for m in visible)
        y1 = max(int(m.get("y", 0)) + int(m["height"]) for m in visible)
    except (KeyError, TypeError, ValueError):
        return None
    return x0, y0, max(1, x1 - x0), max(1, y1 - y0)


def primary_monitor_bounds() -> tuple[int, int, int, int] | None:
    monitors = hyprland_monitors()
    visible = [m for m in monitors if isinstance(m, dict) and not m.get("disabled", False)]
    selected = next((m for m in visible if m.get("focused")), None)
    if selected is None and visible:
        selected = visible[0]
    if selected is None:
        return None
    try:
        return (
            int(selected.get("x", 0)), int(selected.get("y", 0)),
            max(1, int(selected["width"])), max(1, int(selected["height"])),
        )
    except (KeyError, TypeError, ValueError):
        return None


def capture_grim(x: int, y: int, width: int, height: int):
    if not IS_WAYLAND or shutil.which("grim") is None:
        raise LinuxInputError("Screen capture on Wayland needs grim. Install it with: sudo pacman -S grim")
    import cv2
    import numpy as np

    width, height = max(1, int(width)), max(1, int(height))
    geometry = f"{int(x)},{int(y)} {width}x{height}"
    try:
        result = subprocess.run(
            ["grim", "-g", geometry, "-"],
            check=True,
            capture_output=True,
            timeout=3.0,
        )
    except FileNotFoundError as exc:
        raise LinuxInputError("Screen capture on Wayland needs grim. Install it with: sudo pacman -S grim") from exc
    except subprocess.CalledProcessError as exc:
        detail = exc.stderr.decode("utf-8", "replace").strip()
        raise LinuxInputError(detail or "grim could not capture the selected screen area") from exc
    except subprocess.TimeoutExpired as exc:
        raise LinuxInputError("grim timed out while capturing the screen") from exc
    image = cv2.imdecode(np.frombuffer(result.stdout, dtype=np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        raise LinuxInputError("grim returned an image that could not be decoded")
    if image.shape[:2] != (height, width):
        image = cv2.resize(image, (width, height), interpolation=cv2.INTER_AREA)
    return np.ascontiguousarray(image)


def _ydotool(args: Sequence[str]) -> None:
    if shutil.which("ydotool") is None:
        raise LinuxInputError("Keyboard and mouse input on Wayland needs ydotool. Install it with: sudo pacman -S ydotool")
    try:
        result = subprocess.run(
            ["ydotool", *args],
            check=True,
            capture_output=True,
            text=True,
            timeout=2.0,
        )
    except FileNotFoundError as exc:
        raise LinuxInputError("Keyboard and mouse input on Wayland needs ydotool. Install it with: sudo pacman -S ydotool") from exc
    except subprocess.CalledProcessError as exc:
        detail = (exc.stderr or exc.stdout or "").strip()
        if "socket" in detail.lower() or "connect" in detail.lower():
            detail = "ydotoold is not running or its socket is not accessible"
        raise LinuxInputError(detail or "ydotool could not send input") from exc
    except subprocess.TimeoutExpired as exc:
        raise LinuxInputError("ydotool timed out. Check that ydotoold is running") from exc


def _keycodes(name: str) -> list[int]:
    key = str(name).strip().lower()
    if key in _KEYCODES:
        return [_KEYCODES[key]]
    if len(key) == 1 and key in _KEYCODES:
        return [_KEYCODES[key]]
    raise LinuxInputError(f"Key {name!r} is not supported by the Wayland input backend")


def key_event(name: str, pressed: bool) -> None:
    key = str(name)
    with _KEY_LOCK:
        if pressed:
            codes = _keycodes(key)
            _PRESSED_KEYS[key] = codes
            for code in codes:
                _ydotool(["key", f"{code}:1"])
        else:
            codes = _PRESSED_KEYS.pop(key, None)
            if codes is None:
                codes = _keycodes(key)
            for code in reversed(codes):
                _ydotool(["key", f"{code}:0"])


def release_all_keys() -> None:
    with _KEY_LOCK:
        keys = list(_PRESSED_KEYS.items())
        _PRESSED_KEYS.clear()
        for _name, codes in keys:
            for code in reversed(codes):
                try:
                    _ydotool(["key", f"{code}:0"])
                except LinuxInputError:
                    pass


def move_mouse(x: int, y: int) -> None:
    if IS_HYPRLAND:
        hyprctl_dispatch(f"hl.dsp.cursor.move({{ x = {int(x)}, y = {int(y)} }})")
        return
    _ydotool(["mousemove", "--absolute", str(int(x)), str(int(y))])


def mouse_button(pressed: bool) -> None:
    _ydotool(["click", "0x40" if pressed else "0x80"])


def ydotool_ready() -> tuple[bool, str]:
    if shutil.which("ydotool") is None:
        return False, "ydotool is missing"
    try:
        result = subprocess.run(["ydotool", "debug"], capture_output=True, text=True, timeout=2.0)
    except (OSError, subprocess.SubprocessError) as exc:
        return False, str(exc)
    if result.returncode != 0:
        return False, (result.stderr or result.stdout or "ydotoold is not running").strip()
    return True, "ready"
