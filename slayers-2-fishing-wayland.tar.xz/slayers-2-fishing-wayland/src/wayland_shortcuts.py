from __future__ import annotations

import asyncio
import threading
import time
from collections.abc import Callable

from dbus_next import Message, MessageType, Variant
from dbus_next.aio import MessageBus

PORTAL_SERVICE = "org.freedesktop.portal.Desktop"
PORTAL_PATH = "/org/freedesktop/portal/desktop"
PORTAL_INTERFACE = "org.freedesktop.portal.GlobalShortcuts"
REQUEST_INTERFACE = "org.freedesktop.portal.Request"
SESSION_INTERFACE = "org.freedesktop.portal.Session"
REGISTRY_INTERFACE = "org.freedesktop.host.portal.Registry"
APPLICATION_ID = "org.projectslayers.fishingmacro"

ErrorFn = Callable[[str], None]
TriggerFn = Callable[[str], None]


def _value(value):
    return value.value if isinstance(value, Variant) else value


def _variant_map(value: dict) -> dict:
    return {key: _value(item) for key, item in value.items()}


class PortalShortcuts:
    """Registers global shortcuts through the Wayland desktop portal."""

    def __init__(self, on_error: ErrorFn) -> None:
        self._on_error = on_error
        self._loop = asyncio.new_event_loop()
        self._thread = threading.Thread(target=self._run, name="wayland-shortcuts", daemon=True)
        self._thread.start()
        self._lock = threading.RLock()
        self._bus: MessageBus | None = None
        self._session: str | None = None
        self._callbacks: dict[str, Callable[[], None]] = {}
        self._preferences: dict[str, tuple[str, TriggerFn | None]] = {}
        self._configure_callback: Callable[[dict[str, str]], None] | None = None
        self._start_pending = False
        self._closed = False

    def _run(self) -> None:
        asyncio.set_event_loop(self._loop)
        self._loop.run_forever()

    def add(
        self,
        shortcut_id: str,
        preferred_trigger: str,
        callback: Callable[[], None],
        on_bound: TriggerFn | None = None,
    ) -> str:
        with self._lock:
            self._callbacks[shortcut_id] = callback
            self._preferences[shortcut_id] = (preferred_trigger, on_bound)
            if not self._start_pending and self._session is None and not self._closed:
                self._start_pending = True
                self._loop.call_soon_threadsafe(self._schedule_start)
        return shortcut_id

    def remove(self, shortcut_id: str) -> None:
        with self._lock:
            self._callbacks.pop(shortcut_id, None)

    def configure(self, on_changed: Callable[[dict[str, str]], None] | None = None) -> bool:
        if self._closed or self._session is None:
            self._on_error("The Wayland shortcut portal is not ready yet. Try again in a moment.")
            return False
        asyncio.run_coroutine_threadsafe(self._configure(on_changed), self._loop)
        return True

    def _schedule_start(self) -> None:
        self._loop.call_later(0.12, lambda: asyncio.create_task(self._start()))

    async def _request(self, member: str, signature: str, body: list) -> dict:
        if self._bus is None:
            raise RuntimeError("The desktop portal connection is not ready")
        loop = asyncio.get_running_loop()
        response_future = loop.create_future()
        received: list[Message] = []

        def handler(message: Message) -> bool:
            if message.message_type != MessageType.SIGNAL:
                return False
            if message.interface != REQUEST_INTERFACE or message.member != "Response":
                return False
            if message.path is None:
                return False
            received.append(message)
            if response_future.done():
                return False
            # The request handle is returned by the method call. Responses
            # from unrelated portal requests are ignored below.
            return False

        self._bus.add_message_handler(handler)
        try:
            reply = await self._bus.call(Message(
                destination=PORTAL_SERVICE,
                path=PORTAL_PATH,
                interface=PORTAL_INTERFACE,
                member=member,
                signature=signature,
                body=body,
            ))
            if reply.message_type == MessageType.ERROR:
                raise RuntimeError(reply.body[0] if reply.body else reply.error_name or "Portal request failed")
            handle = str(reply.body[0])

            def take_response(message: Message) -> None:
                if message.path == handle and not response_future.done():
                    response_future.set_result(message.body)

            for message in received:
                take_response(message)
            if not response_future.done():
                # Add a second handler now that we know the exact request path.
                def matching_handler(message: Message) -> bool:
                    if (message.message_type == MessageType.SIGNAL
                            and message.interface == REQUEST_INTERFACE
                            and message.member == "Response"
                            and message.path == handle):
                        if not response_future.done():
                            response_future.set_result(message.body)
                        return True
                    return False

                self._bus.add_message_handler(matching_handler)
                try:
                    response = await asyncio.wait_for(response_future, timeout=120.0)
                finally:
                    self._bus.remove_message_handler(matching_handler)
            else:
                response = response_future.result()
            if not response or int(response[0]) != 0:
                raise RuntimeError("The global shortcut request was cancelled")
            return _variant_map(response[1] or {})
        finally:
            self._bus.remove_message_handler(handler)

    async def _start(self) -> None:
        try:
            self._bus = await MessageBus().connect()
            self._bus.add_message_handler(self._signal)
            registration = await self._bus.call(Message(
                destination=PORTAL_SERVICE,
                path=PORTAL_PATH,
                interface=REGISTRY_INTERFACE,
                member="Register",
                signature="sa{sv}",
                body=[APPLICATION_ID, {}],
            ))
            if registration.message_type == MessageType.ERROR:
                error_name = registration.error_name or ""
                error = registration.body[0] if registration.body else error_name or "Portal registration failed"
                if "UnknownInterface" not in error_name and "UnknownMethod" not in error_name:
                    raise RuntimeError(str(error))
            suffix = str(time.time_ns())
            created = await self._request(
                "CreateSession",
                "a{sv}",
                [{
                    "handle_token": Variant("s", "s2f_req_" + suffix),
                    "session_handle_token": Variant("s", "s2f_session_" + suffix),
                }],
            )
            session = created.get("session_handle")
            if not session:
                raise RuntimeError("The desktop portal did not return a shortcut session")
            self._session = str(session)

            listed = await self._request(
                "ListShortcuts", "oa{sv}", [self._session, {}],
            )
            shortcuts = listed.get("shortcuts") or []
            triggers = self._trigger_map(shortcuts)
            with self._lock:
                wanted = dict(self._preferences)
            missing = [shortcut_id for shortcut_id in wanted if shortcut_id not in triggers]
            if missing:
                shortcut_entries = []
                for shortcut_id in missing:
                    preferred, _callback = wanted[shortcut_id]
                    shortcut_entries.append((shortcut_id, {
                        "description": Variant("s", "Fishing macro " + shortcut_id.replace("_", " ")),
                        "preferred_trigger": Variant("s", preferred),
                    }))
                bound = await self._request(
                    "BindShortcuts",
                    "oa(sa{sv})sa{sv}",
                    [self._session, shortcut_entries, "", {
                        "handle_token": Variant("s", "s2f_bind_" + suffix),
                    }],
                )
                triggers.update(self._trigger_map(bound.get("shortcuts") or []))
            self._notify_bound(triggers)
        except Exception as exc:
            self._on_error(
                "Wayland global shortcuts are unavailable. You can still use the buttons in the macro window. "
                + str(exc)
            )

    def _signal(self, message: Message) -> bool:
        if message.message_type != MessageType.SIGNAL or message.interface != PORTAL_INTERFACE:
            return False
        if message.member == "ShortcutsChanged" and len(message.body) >= 2:
            session = str(message.body[0])
            if session != self._session:
                return False
            triggers = self._trigger_map(message.body[1] or [])
            self._notify_bound(triggers)
            callback, self._configure_callback = self._configure_callback, None
            if callback is not None:
                try:
                    callback(triggers)
                except Exception:
                    pass
            return False
        if message.member != "Activated" or len(message.body) < 2:
            return False
        session, shortcut_id = str(message.body[0]), str(message.body[1])
        if session != self._session:
            return False
        with self._lock:
            callback = self._callbacks.get(shortcut_id)
        if callback is not None:
            try:
                callback()
            except Exception:
                pass
        return False

    @staticmethod
    def _trigger_map(shortcuts: list) -> dict[str, str]:
        out: dict[str, str] = {}
        for entry in shortcuts:
            try:
                shortcut_id, properties = entry
                props = _variant_map(properties)
                trigger = str(props.get("trigger_description") or "").strip()
                if trigger:
                    out[str(shortcut_id)] = trigger
            except (TypeError, ValueError):
                continue
        return out

    def _notify_bound(self, triggers: dict[str, str]) -> None:
        with self._lock:
            callbacks = dict(self._preferences)
        for shortcut_id, trigger in triggers.items():
            on_bound = callbacks.get(shortcut_id, ("", None))[1]
            if on_bound is not None:
                try:
                    on_bound(trigger)
                except Exception:
                    pass

    async def _configure(self, on_changed: Callable[[dict[str, str]], None] | None) -> None:
        try:
            if self._bus is None or self._session is None:
                raise RuntimeError("The desktop portal connection is not ready")
            self._configure_callback = on_changed
            reply = await self._bus.call(Message(
                destination=PORTAL_SERVICE,
                path=PORTAL_PATH,
                interface=PORTAL_INTERFACE,
                member="ConfigureShortcuts",
                signature="osa{sv}",
                body=[self._session, "", {}],
            ))
            if reply.message_type == MessageType.ERROR:
                raise RuntimeError(reply.body[0] if reply.body else reply.error_name or "Shortcut settings failed")
        except Exception as exc:
            self._configure_callback = None
            self._on_error("Could not update Wayland shortcuts: " + str(exc))

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._loop.is_running():
            try:
                future = asyncio.run_coroutine_threadsafe(self._close_session(), self._loop)
                future.result(timeout=1.5)
            except Exception:
                pass
            self._loop.call_soon_threadsafe(self._loop.stop)
        if self._thread.is_alive():
            self._thread.join(timeout=1.0)

    async def _close_session(self) -> None:
        if self._bus is None:
            return
        if self._session:
            try:
                await self._bus.call(Message(
                    destination=PORTAL_SERVICE,
                    path=self._session,
                    interface=SESSION_INTERFACE,
                    member="Close",
                ))
            except Exception:
                pass
        try:
            self._bus.disconnect()
        except Exception:
            pass
