from __future__ import annotations

import os
import sys
from pathlib import Path

APP_ID = "org.projectslayers.fishingmacro"
GENERATED_MARKER = "X-Generated-By=slayers-2-fishing"


def _quote_exec(path: Path) -> str:
    return '"' + str(path).replace("\\", "\\\\").replace('"', '\\"') + '"'


def install(project_root: Path) -> Path | None:
    data_home = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local/share"))
    applications = data_home / "applications"
    target = applications / f"{APP_ID}.desktop"
    launch = (project_root / "Launch.sh").resolve()
    content = "\n".join((
        "[Desktop Entry]",
        "Type=Application",
        "Name=Project Slayers 2 Fishing Macro",
        "Comment=Fishing macro for Sober on Hyprland",
        f"Exec={_quote_exec(launch)}",
        f"TryExec={_quote_exec(launch)}",
        "Terminal=false",
        "Categories=Utility;Game;",
        GENERATED_MARKER,
        "",
    ))

    if target.exists():
        try:
            existing = target.read_text(encoding="utf-8")
        except OSError:
            existing = ""
        if GENERATED_MARKER not in existing:
            print(f"Skipped {target}, it already belongs to another application.")
            return None
        if existing == content:
            return target

    applications.mkdir(parents=True, exist_ok=True)
    target.write_text(content, encoding="utf-8")
    print(f"Installed desktop identity at {target}")
    return target


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: install_desktop.py PROJECT_ROOT", file=sys.stderr)
        return 2
    install(Path(sys.argv[1]).resolve())
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
