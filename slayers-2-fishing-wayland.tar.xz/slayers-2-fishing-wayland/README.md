# Project Slayers 2 Fishing Macro para Linux Wayland

Versión para Sober ejecutándose como ventana nativa Wayland en Hyprland,
especialmente orientada a Arch Linux/Omarchy.

## Cómo funciona

El macro captura la ventana del juego con `grim`, detecta por color la barra
del minijuego y sigue la pelota para controlar el clic. Usa `ydotool` para
enviar teclado y ratón sin leer la memoria de Roblox. Puede mantener `T` o
hacer clic para recoger, reconocer el nombre del pez con Tesseract, compensar
el movimiento con `WASD`, activar cebo, descartar peces, automatizar misiones
y enviar avisos a un webhook de Discord.

Las coordenadas, colores, tiempos y movimientos son específicos de cada
resolución y lugar de pesca. Calibra el macro en tu equipo antes de usarlo.
En el primer arranque, el portal de accesos directos puede pedir que asignes
F1-F4; usa **Change** para volver a abrir esa configuración.

## Requisitos

- Linux con una sesión Wayland activa.
- Hyprland y Sober abiertos.
- Python 3.10 o superior. `uv` administra el entorno virtual y `uv.lock`.
- `tk`, `grim`, `ydotool` y `hyprland`; `tesseract` solo es necesario para leer nombres de peces.
- Servicio de usuario `ydotool.service` activo y acceso a `/dev/uinput`.

## Instalación en Arch Linux/Omarchy

Instala las herramientas del sistema:

```bash
sudo pacman -S uv tk hyprland grim ydotool tesseract
systemctl --user enable --now ydotool.service
```

Después, desde la carpeta del proyecto:

```bash
chmod +x Setup.sh Launch.sh
./Setup.sh
./Launch.sh
```

Abre Sober y el juego antes de seleccionar posiciones. `Setup.sh` sincroniza
las dependencias, crea la identidad de escritorio para los atajos y comprueba
`ydotool`. Si `/dev/uinput` no es accesible, cierra sesión y vuelve a entrar;
después inicia de nuevo el servicio.

## Extraerlo en Linux

Desde la carpeta donde descargaste el archivo:

```bash
mkdir -p slayers-2-fishing-wayland
tar -xJf slayers-2-fishing-wayland.tar.xz -C slayers-2-fishing-wayland
cd slayers-2-fishing-wayland/slayers-2-fishing-wayland
```

El paquete ya contiene `Setup.sh`, `Launch.sh`, `config.json`, `pyproject.toml`
y `uv.lock`. No es necesario crear manualmente un entorno virtual; `uv sync`
crea `.venv/`, que es local y no forma parte del código fuente.

Si falta alguna herramienta, instala `tar`/`xz` con el gestor de paquetes de tu
distribución. En Debian/Ubuntu, `sudo apt install tar xz-utils unzip` instala
las utilidades de extracción, pero esta variante sigue requiriendo Hyprland,
Wayland, `grim` y `ydotool` para ejecutarse.

## Configuración y webhook

Realiza una pesca manual para calibrar la barra, los colores, el punto de
lanzamiento, el área de recolección y los movimientos. Configura el webhook
desde un canal de Discord en **Integraciones > Webhooks** y pega únicamente una
URL HTTPS. No la compartas: permite publicar mensajes en el canal.

La misión de pesca debe completarse manualmente una vez para registrar sus
puntos y clics. Después habilítala y ajusta sus retrasos; un retardo muy corto
puede producir falsos positivos.

## Aviso

El video enlazado por el autor afirma que el desarrollador principal no
rastrea ni sanciona estos macros, pero eso puede cambiar. Revisa las reglas
actuales del juego y úsalo bajo tu propia responsabilidad.

Video de referencia: <https://www.youtube.com/watch?v=medoNFtBf0s>
