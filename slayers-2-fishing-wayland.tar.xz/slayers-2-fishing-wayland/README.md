# Project Slayers 2 Fishing Macro

## Omarchy and Arch Linux

This version supports Sober running as a native Wayland window under Hyprland.

Install the system tools once:

```sh
sudo pacman -S uv tk hyprland grim ydotool tesseract
systemctl --user enable --now ydotool.service
```

`tesseract` is only needed for fish name reading. The ydotool package installs its user service and udev rule. If the service cannot access `/dev/uinput` after installation, log out and back in, then start the service again.

From the project directory, sync Python dependencies, register the desktop identity needed for global shortcuts, and launch the macro:

```sh
./Setup.sh
./Launch.sh
```

Open Sober and the game before selecting screen positions. The macro finds the Sober window through Hyprland, captures it with `grim`, and uses `ydotool` to send input. Global hotkeys are registered through the desktop portal. On the first run, the portal may ask you to choose F1–F4. Use a hotkey's **Change** button to open the portal shortcut settings again.

The Python environment and lockfile are managed with `uv`. The virtual environment is created in `.venv/` and is not committed.
