#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)"
unset VIRTUAL_ENV

if ! command -v uv >/dev/null 2>&1; then
    printf '%s\n' "uv is required. On Arch Linux, install it with: sudo pacman -S uv"
    exit 1
fi

printf '%s\n' "Syncing the Python environment with uv..."
uv sync --project "$ROOT"

if ! uv run --project "$ROOT" python -c 'import tkinter' >/dev/null 2>&1; then
    printf '%s\n' "Tkinter is missing. On Arch Linux, install it with: sudo pacman -S tk"
    exit 1
fi

missing=()
for tool in hyprctl grim ydotool; do
    if ! command -v "$tool" >/dev/null 2>&1; then
        missing+=("$tool")
    fi
done

if ((${#missing[@]})); then
    printf '\n%s\n' "Missing system tools: ${missing[*]}"
    printf '%s\n' "On Arch Linux, install them with: sudo pacman -S hyprland grim ydotool"
    printf '%s\n' "Start the ydotoold service after installation."
    exit 1
fi

uv run --project "$ROOT" python "$ROOT/src/install_desktop.py" "$ROOT"

if command -v systemctl >/dev/null 2>&1 && ! systemctl --user is-active --quiet ydotool.service; then
    printf '%s\n' "Start the input daemon with: systemctl --user enable --now ydotool.service"
fi

if ! ydotool debug >/dev/null 2>&1; then
    printf '%s\n' "ydotoold is not reachable. Start it with: systemctl --user enable --now ydotool.service"
    printf '%s\n' "If access to /dev/uinput is denied, log out and back in after installing ydotool."
else
    printf '%s\n' "ydotoold is ready."
fi

printf '%s\n' "Python packages are ready. Use ./Launch.sh to start the macro."
